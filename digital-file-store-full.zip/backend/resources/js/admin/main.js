import { createApp } from 'vue'
import Dashboard from './Dashboard.vue'
createApp(Dashboard).mount('#app')
