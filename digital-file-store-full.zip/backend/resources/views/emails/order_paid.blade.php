<h3>Cảm ơn bạn đã mua: {{ $product->title }}</h3>
<p>Sản phẩm: <strong>{{ $product->title }}</strong></p>
<p>Link tải (Google Drive):</p>
<p><a href="{{ $product->drive_link }}" target="_blank">Tải xuống</a></p>
<p>Nếu bạn gặp lỗi tải, liên hệ support.</p>
