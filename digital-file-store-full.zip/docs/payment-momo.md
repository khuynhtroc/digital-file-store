# Momo quick guide (sandbox)

- Use Momo's sandbox partner code and keys.
- Create payment request from backend, redirect user to Momo checkout page, handle callback to mark order as paid.
