# Stripe sandbox

- Create a Stripe account, get test keys, use Stripe Checkout or PaymentIntents.
- Use Stripe webhook to confirm payment.
